﻿using AutoMapper;
using TodoApp.Domain;
using TodoApp.Dtos;

namespace TodoApp
{
    public class BookMappingProfile : Profile
    {
        public BookMappingProfile()
        {
            CreateMap<Book, BookDto>();
            CreateMap<CreateBookDto, Book>();
            CreateMap<UpdateBookDto, Book>();
        }
    }
}
