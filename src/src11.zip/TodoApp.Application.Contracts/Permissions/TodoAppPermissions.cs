﻿namespace TodoApp.Permissions;

public static class TodoAppPermissions
{
    public const string GroupName = "TodoApp";

    //Add your own permission names. Example:
    //public const string MyPermission1 = GroupName + ".MyPermission1";
}
