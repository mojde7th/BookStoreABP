﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("TodoApp.Application.Tests")]
