﻿using Volo.Abp.Localization;

namespace TodoApp.Localization;

[LocalizationResourceName("TodoApp")]
public class TodoAppResource
{

}
