﻿namespace TodoApp;

public static class TodoAppDomainErrorCodes
{
    /* You can add your business exception error codes here, as constants */
}
