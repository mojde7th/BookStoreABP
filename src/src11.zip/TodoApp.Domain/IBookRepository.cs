﻿//using System;
//using System.Collections.Generic;
//using System.Threading.Tasks;
//using Volo.Abp.Domain.Repositories;

//namespace TodoApp.Domain
//{
//    public interface IBookRepository : IRepository<Book, Guid>
//    {
//        Task<List<Book>> GetListAsync();
//        Task<Book> GetAsync(Guid id);
//        Task InsertAsync(Book book);
//        Task UpdateAsync(Book book);
//        Task DeleteAsync(Guid id);
//    }
//}
