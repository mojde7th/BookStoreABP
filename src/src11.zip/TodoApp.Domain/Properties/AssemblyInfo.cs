﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("TodoApp.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("TodoApp.TestBase")]
