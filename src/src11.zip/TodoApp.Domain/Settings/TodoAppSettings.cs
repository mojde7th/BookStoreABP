﻿namespace TodoApp.Settings;

public static class TodoAppSettings
{
    private const string Prefix = "TodoApp";

    //Add your own setting names here. Example:
    //public const string MySetting1 = Prefix + ".MySetting1";
}
