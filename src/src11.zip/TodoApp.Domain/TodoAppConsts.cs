﻿namespace TodoApp;

public static class TodoAppConsts
{
    public const string DbTablePrefix = "App";

    public const string DbSchema = null;
}
