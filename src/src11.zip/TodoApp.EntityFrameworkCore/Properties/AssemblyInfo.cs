﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("TodoApp.EntityFrameworkCore.Tests")]
