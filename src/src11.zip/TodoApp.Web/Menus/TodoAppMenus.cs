﻿namespace TodoApp.Web.Menus;

public class TodoAppMenus
{
    private const string Prefix = "TodoApp";
    public const string Home = Prefix + ".Home";

    //Add your menu items here...

}
