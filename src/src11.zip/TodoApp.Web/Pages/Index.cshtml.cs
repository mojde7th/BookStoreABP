﻿namespace TodoApp.Web.Pages;

public class IndexModel : TodoAppPageModel
{
    public void OnGet()
    {

    }
}
