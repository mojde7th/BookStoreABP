﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("TodoApp.Web.Tests")]
