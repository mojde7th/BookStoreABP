﻿using AutoMapper;

namespace TodoApp.Web;

public class TodoAppWebAutoMapperProfile : Profile
{
    public TodoAppWebAutoMapperProfile()
    {
        //Define your AutoMapper configuration here for the Web project.
    }
}
